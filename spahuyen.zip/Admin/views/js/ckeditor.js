CKEDITOR.replace('editor1', {
    filebrowserBrowseUrl: '../lib/ckfinder/ckfinder.html',
    filebrowserUploadUrl: '../lib/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files'
});