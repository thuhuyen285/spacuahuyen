<?php
header("location: ");
?>  