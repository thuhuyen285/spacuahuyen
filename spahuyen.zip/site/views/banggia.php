    <!-- Noi dung -->
    <section>
            <div class="container ">
                <div class="row d-flex justify-content-center">
                    <div class="col-lg-11 mt-2 ">
                        <ul itemscope="" class="navleft" itemtype="http://schema.org/BreadcrumbList" id="breadcrumbs">
                            <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                <i class="fa fa-home" aria-hidden="true"></i>
                            </li>
                            <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                <a itemscope="" itemtype="http://schema.org/Thing" itemprop="item" href="" title="Thông Tin Doanh Nghiệp">
                                    <span itemprop="name" class="text-dark">Tin Tức Thẩm Mỹ Viện</span>
                                </a>
                                <meta itemprop="position" content="2"> </li>
                            <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                                <a itemscope="" itemtype="http://schema.org/Thing" itemprop="item" href="" title="Liên Hệ">
                                    <span itemprop="name" class="text-dark"> Bảng Giá Dịch Vụ Làm Đẹp Tại Thẩm Mỹ Viện Linh Hương</span>
                                </a>
                                <meta itemprop="position" content="3">
                            </li>
                        </ul>
                        
                        <hr>
                        <h5 class=""><span style="color:#ff0000">► <strong>Giảm 30% cho 100 kh&aacute;ch h&agrave;ng đầu ti&ecirc;n</strong></span></h5>

                        <div class="text-left m-auto content d-flex justify-content-center flex-column">
                            <h5><span style="font-size:18px">Thẩm mỹ spa<strong> Linh Hương</strong> l&agrave; nơi kinh doanh chuy&ecirc;n về dịch vụ l&agrave;m đẹp, nơi đ&acirc;y c&oacute; tẩt cả c&aacute;c dịch vụ như: Chăm s&oacute;c da,massage giảm mỡ,phẫu thuật thẩm mỹ, gội đầu dưỡng sinh, phun xăm phong thuỷ thẩm mỹ.</span></h5>

                            <h2><strong>1.Chi tiết bảng giá dịch vụ phun xăm mày môi </strong></h2>


                            <p>&nbsp;</p>
                            <img class="pb-4" src="<?=PATH_IMG?>banggia2.jpg" alt="">
                        <h4> 1.1. Phun môi baby lips</h4>
                        <div class="ml-4 mb-3">
                            <p>Đôi môi chính là nét đẹp gợi cảm của người phụ nữ. Bờ môi quyến rũ, cùng với nụ cười rạng ngời sẽ làm rung động, hay xuyến xao lòng người. Tuy vậy, không phải ai cũng sở hữu một đôi môi hồng xinh xắn. Hãy đến đây và sử dụng dịch vụ phun môi của chúng tôi để có một đôi môi cực xinh.</p> 
                            <p>-Tiết kiệm thời gian thực hiện. <br>
                                -Mịn <br>
                                -Đậm <br>
                                -Đều  <br>
                                -Tình trạng khô môi, bong tróc môi do môi thiếu độ ẩm hoặc khô môi do cơ địa được khắc phục rõ rệt <br>
                                -Môi đậm màu hơn và tươi hơn, quá trình phục hồi môi nhanh hơn. </p>
                        <img class="pb-4" src="<?=PATH_IMG?>1.3.jpg" alt="">
                                
                            <b > Giá dịch vụ: </b> Giá gốc <span class="span">1.800.000đ</span>  đang giảm còn <span class="span">1.200.000đ</span> 
                            </div>
                            
                            <h4> 1.2. Phun môi Lipstick phủ collagens TBG</h4>

                            <div class="ml-4 mb-3">
                                <p>
                            -Phương pháp giúp tạo đường nét, màu sắc mắt – môi – mày đẹp tự nhiên như thật <br>
                            -Công nghệ hứa hẹn duy trì hiệu quả lâu dài, giúp chị em luôn đẹp - sang, sẵn sàng tỏa sáng.</p>
                            <img  class="pb-4" src="<?=PATH_IMG?>1.1.PNG" alt="">

                            <b> Giá dịch vụ: </b> Giá gốc <span  class="span">3.000.000đ</span>  đang giảm còn <span  class="span">2.100.000đ</span> 
                            </div>
                            <h4> 1.3. Phun môi Leaded Lips (Thâm nhiều)</h4>
                            <div class="ml-4 mb-3">
                                    <p>
                                Bờ môi đậm giúp bạn có cảm giác tự tin hơn. Đặc biệt là những lúc phải đi gặp đối tác hoặc khách hàng. </p>
                                <img  class="pb-4" src="<?=PATH_IMG?>1.4.jpg" alt="">
                                <b> Giá dịch vụ: </b> Giá gốc <span  class="span">3.000.000đ</span>  đang giảm còn <span  class="span">2.100.000đ</span> 
                            </div>
                            <h4>1.4. Khử thâm môi Baby Doll </h4>
                            <div class="ml-4 mb-3">
                                <p>Thâm môi làm cho bạn mất đi vẻ đẹp tự nhiên vốn có của người phụ nữ, làm cho bạn mất ấn tượng trước mặt bạn bè, người yêu. Nó còn khiến cho bạn mất tự tin trong mọi trường hợp. Chúng tôi cam kết khử thâm môi hoàn toàn.
                                </p> <img class="pb-3" src="<?=PATH_IMG?>1.5.jpg" alt="">

                                <b> Giá dịch vụ: </b> Giá gốc <span  class="span">1.200.000đ</span>  đang giảm còn <span  class="span">840.000đ</span> 
                            </div>
                            
                            <h4>1.5. Phun chạm hạt sharding  </h4>
                            <div class="ml-4 mb-3">
                                <p>
                                    Quy trình Phẩy Hạt Nano Sharding <br>
                                    – Bước 1: Thăm khám và tư vấn trực tiếp bởi các chuyên viên giàu kinh nghiệm để tìm ra giải pháp tối ưu cho khách hàng, cũng như lựa chọn màu mực phù hợp với màu lông chân mày thật của khách hàng.
                                    <br> – Bước 2: Tiến hành vệ sinh tiệt trùng cho vùng da thực hiện.
                                    <br> – Bước 3: Đo đạc, vẽ chân mày trước cho khách hàng bằng chì kẻ mày.
                                    <br> – Bước 4: Ủ tê khoảng 20 phút.
                                    <br> – Bước 5: Tiến hành sử dụng đầu bút chuyên dụng để phun vi chạm theo khuôn đã vẽ. Đầu kim sẽ di chuyển có kiểm soát nhẹ nhàng trên bề mặt da, đồng thời mực sẽ được phun ra với những đường nét tinh vi theo dạng sợi lông mày xuôi về phía cuối đuôi mắt.
                                </p> <img  class="pb-3" src="<?=PATH_IMG?>1.6.jpg" alt="">
                                <b> Giá dịch vụ: </b> Giá gốc <span  class="span">799.000đ</span>  đang giảm còn <span  class="span">599.000đ</span>
                            </div> 
                            
                            <h4>1.6.Thêu chân mày 6D Ombre  </h4>
                            <div class="ml-4 mb-3">
                                <p>
                                Phun thêu chân mày 6D là kỹ thuật sử dụng bút phun xăm chuyên dụng với đầu bút sử dụng các vi kim siêu nhỏ chứa mực được các kỹ thuật viên tiến hành vẽ dáng lông mày lên lớp biểu bì của da. 
                            <br> Phương pháp này giúp bạn tiết kiệm được thời gian, công sức, chi phí sử dụng chì, phấn kẻ mày mỗi ngày  </p>
                            </p> <img class="pb-3" src="<?=PATH_IMG?>1.7.jpg" alt="">
                            <b> Giá dịch vụ: </b> Giá gốc <span  class="span">1.200.000đ</span>  đang giảm còn <span  class="span">840.000đ</span>
                            </div>
                            <h4>1.7.Tạo sợi Full Chân Mày (9D – 12D)</h4>
                            <div class="ml-4 mb-3">
                                <p>Là phương pháp mà các chuyên gia thẩm mỹ dùng một loại dao khắc chuyên biệt có lưỡi cực bén và nhỏ để đưa mực xăm vào da. Khắc từng sợi theo hình dáng tự nhiên của lông mày với dạng cong gần giống như sợi lông mày thật. Từng sợi lông được tạo tỉ mỉ, theo đường nét của một sợi lông mày thật. Phần đầu hơi to, nhạt, phần giữa thon nhỏ, đậm. Phần đuôi của sợi lông thì sắc nhọn đậm nét những chuốt cong.
                            </p> <img class="pb-3" src="<?=PATH_IMG?>1.8.jpg" alt="">
                        <b> Giá dịch vụ: </b> Giá gốc <span  class="span">1.800.000đ</span>  đang giảm còn <span  class="span">1.260.000đ</span>
                        </div>
                        
                        <h4>1.8.Xử lý màu cũ trước khi làm lại</h4>
                        <div class="ml-4 mb-3">
                                <p>
                                    
                                Có rất nhiều chị em phản ánh rằng sau phun lông mày, do một số các loại chăm sóc không đúng cách hoặc do dị ứng với một số các thành phần nào đó mà làm lông mày bị xăm hỏng. Do đó xử lý màu cũ trước khi làm lại là một bước hoàn toàn quan trọng.
                                </p><img class="pb-3" src="<?=PATH_IMG?>1.9.png" alt="">
                                <b> Giá dịch vụ: </b> Giá gốc <span  class="span">500.000đ</span>  đang giảm còn <span  class="span">350.000đ</span>
                            </div>
                            
                        <h4>1.9.Laze xóa sửa chân mày hư hỏng nặng</h4>
                            <div class="ml-4 mb-3">
                            <p> Xóa sửa lông mày hư thực ra rất đơn giản và an toàn nếu các thiết bị sử dụng, cách thức phun xăm đảm bảo được quy chuẩn. Một số người lo sợ sẽ ảnh hưởng đến da, để lại sẹo, không an toàn…nhưng điều này chỉ xảy ra với cơ sở kém chất lượng.
                            </p><img class="pb-3" width="75%" src="<?=PATH_IMG?>2.1.jpg" alt="">
                            <b> Giá dịch vụ: </b> Giá gốc <span  class="span">1.000.000đ</span>  đang giảm còn <span  class="span">700.000đ</span>

                            </div>

                            <h2 class="mt-3"><strong>2.Mí mắt </strong></h2>
                                    <img class="pt-3 pb-3" src="<?=PATH_IMG?>mimat.PNG" alt="">
                                    ► Quy trình phun mí mở tròng  ở thẩm mỹ viện Linh Hương : <br>
                                    <div class="ml-4 mb-3">
                                    <b>Bước 1:</b> Xem hiện trạng mí mắt và tư vấn kỹ càng cho khách hàng.<br>
                                    <div class="ml-4 ">
                                        - Người có đôi mắt nhỏ, ngắn muốn mắt trông to tròn hơn<br>
                                        - Người có nếp mí ngắn, thưa và không rõ ràng.<br>
                                        - Cặp mắt mờ nhạt, thiếu sắc nét không tạo sự cuốn hút.<br>
                                        - Muốn có đường viền mí sắc nét hơn khỏi mất công trang điểm.<br>
                                    </div><br>
                                    <b>Bước 2:</b> Nắm được kiểu dáng, màu sắc và sở thích của khách hàng để tiến hành Phun Mí.<br><br>

                                    <b>Bước 3:</b> Vệ sinh và ủ tê chuyên dụng cho khách hàng.<br><br>

                                    <b>Bước 4:</b> Cho khách kiểm tra tất cả dụng cụ đều MỚI và RIÊNG BIỆT theo đúng quy chuẩn Bộ Y Tế <br><br>


                                    <b>Bước 5:</b> Sau khi chuyên viên phun xong sẽ có Giám Sát Chuyên Môn lại kiểm tra kỹ càng, tỉ mỉ từng đường kim, chi ly từng vết mực, dáng mẫu phù hợp, khi tác phẩm đẹp và chuẩn thì mới xong.
                                    <br><br>
                                    <b>Bước 6:</b> Dặn dò khách hàng và cấp PHIẾU BẢO HÀNH (có giá trị từ 3-4 tháng)<br>

                                    Với Công nghệ PHUN MÍ MỞ TRÒNG MẮT NAI mới nhất kết hợp với màu mực chiết xuất từ thảo dược thiên nhiên cùng với máy móc trang thiết bị hiện đại, chuyên viên tay nghề cao thì chất lượng từng tác phẩm luôn ở mức Đẹp Nhất.

                                    Thời gian làm chỉ tầm 30p. Không sưng, Không đau, Không ảnh hưởng tới thị lực An Toàn tuyệt đối Đẹp tự nhiên .
                                </div><img src="<?=PATH_IMG?>phunmi.jpg" alt="">
                            
                            <h2 class="mt-3"><strong>3.Laser xóa xăm </strong></h2>
                            <div class="ml-4 mb-3">
                                <p> 
                            <b>1.1 .</b>  Laser nốt ruồi  <br>
                                <b>1.2 .</b> Laser nám – tàn nhang <br>
                            <b> 1.3 .</b> Laser mụn thịt <br>
                            <b>1.4 .</b> Xóa hình xăm <br>
                                </p>
                            <b> Tại Linh Hương chúng tôi không cam kết xóa hiệu quả 99% cho bạn mà cam kết 90-99%. Vì:</b> <br>

                            <b> ✓ Tùy vào mực xăm của bạn là mực gì:</b> mực tàu (xưa), mực bút, xăm xe, mực in, và một số mực xăm tự chế khác... Với các loại mực xăm này, Bạn hãy đến trực tiếp Linh Hương để được soi da và thăm khám bởi đội ngũ chuyên gia của chúng tôi sẽ có mức cam kết tốt nhất cho bạn nhé.
                            <br>
                                <b>✓ Đối với các mực xăm hiện đại:</b> thường xóa xăm đạt hiệu quả rất cao có thể lên đến 99%.
                                <br>
                                <b>✓ Các mực xăm màu: </b>Linh Hương khẳng định công nghệ cao Alpha Pro+ xóa các loại mực xăm trên với hiệu quả cao vì được xóa xăm bằng laser với bước sóng dài hơn và phải thực sự ổn định. Ngoài ra, yếu tố tay nghề kỹ thuật của chuyên gia cũng quyết định rất lớn đến hiệu quả khi xóa các loại mực xăm màu này.
                                <br>
                                <img class="pt-4 pb-3" src="<?=PATH_IMG?>xoaxam.jpg" alt="">
                            <b> ✓ Và một yếu tố cuối cùng nữa là độ sâu hay nông của hình xăm:</b>
                                Bạn xăm bằng công nghệ gì, máy gì, tay nghề thợ xăm thế nào…cũng sẽ quyết định đến độ sâu nông của hình xăm. Để biết được điều này Bạn nên đến trực tiếp Beryl Beauty để được kiểm tra soi da trực tiếp để đưa ra cam kết.
                                                            
                                
                            </div>
                            <h2 class="mt-3"><strong>4.Bảng giá chăm sóc da - điều trị da </strong></h2>
                        <img class="pb-3 pt-2" src="<?=PATH_IMG?>chamsocda.PNG" alt="">
                            <p>
                                Da đã bảo vệ cơ thể trước các tác nhân của môi trường, không những thế da còn tạo nên vẻ đẹp của chúng ta. 
                                Do đó, không có lý do gì mà bạn lại không bảo vệ và chăm sóc da thường xuyên hơn. 
                            <b> Linh Hương</b> Spa khuyên bạn nên chăm sóc da để luôn giữ được một làn da khỏe mạnh, sáng mịn mỗi ngày. 
                                Chúng tôi cam kết với các dịch vụ chăm sóc da mặt tại <b>Linh Hương </b> bạn sẽ hài lòng với kết quả mà chúng tôi 
                                đem lại cho làn da của bạn. </p>
                                <img class="pb-3" src="<?=PATH_IMG?>spa.jpg" alt="">
                            <b>Lợi ích về sức khỏe làn da:</b> 
                            <div class="ml-4 mb-3">
                                1. Chăm sóc da tại Spa sẽ giúp bạn phân tích đúng đắn tình trạng da hiện tại của bạn <br>
                                2. Lựa chọn phương pháp phù hợp để cải thiện làn da tốt nhất <br>
                                3. Sử dụng các trang thiết bị để loại bỏ các bụt bẩn, tạp chất sâu dưới lỗ chân lông mà tay thường bạn không thể loại bỏ tại nhà<br>
                                    4. Chăm sóc da mặt đảm bảo độ trẻ hóa da qua các thao tác massage tại Spa<br>
                                    5. Giúp cải thiện độ sáng tự nhiên cho da mặt khi chăm sóc da tại Spa<br></div>
                                <b>Lợi ích về tinh thần cho bạn</b>
                            <div class="ml-4 mb-3">
                                    1. Việc chăm sóc da mặt giúp giảm căng thẳng cho hệ thần kinh của bạn<br>
                                    2.  Các chuyên gia, kỹ thuật viên sẽ giải phóng Hormone Endorphin làm cho bạn hạnh phúc và trở về trạng thái thoải mái<br>
                                    3. Hưởng thụ không gian và được phục vụ bởi đội ngũ chuyên viên chuyên nghiệp cũng khiến cho tinh thần của bạn được cải thiện lên đáng kể
                                    <br> 4.  Loại bỏ được những rắc rối, khó khăn khi phải tự mình chăm sóc da tại nhà
                                </div>
                                <img class="pb-3" src="<?=PATH_IMG?>dieutrida.PNG" alt="">
                                Sau khi thực hiện dịch vụ chăm sóc da tại Linh Hương, khách hàng sẽ hoàn toàn hài lòng với kết quả mang lại: <br>
                                    <div class="ml-4 mb-3">
                                        Chăm sóc làn da khỏe mạnh từ trong ra ngoài <br>
                                        ♦ Da trở nên săn chắc, mịn màng hơn<br>
                                        ♦ Da lên tone sáng da tự nhiên<br>
                                        ♦ Loại bỏ các loại mụn cám, mụn đầu đen cứng đầu<br>
                                        ♦ Loại bỏ tình trạng da kém sắc, khô ráp,..
                                        ♦ Cải thiện loại bỏ nếp nhăn, da căng bóng đầy sức sống<br>
                                        ♦ Xua tan những căng thẳng, mệt mỏi<br>
                                    </div>
                            <h2 class="mt-3"><strong>5.Bảng giá dịch vụ tắm trắng body - giảm mỡ  </strong></h2>
                                    <img  class="pt-3 pb-3" src="<?=PATH_IMG?>body.PNG" alt="">
                                    <img  class="pt-3 pb-3" src="<?=PATH_IMG?>tamtrang.PNG" alt="">

                                    Thừa cân, mỡ bụng, đùi, bắp tay,…béo sau sinh đã khiến bạn mất tự tin, mất đi 1 phần niềm vui trong cuộc sống, một gây ra nhiều vấn đề về sức khỏe. Mỡ của bạn cứ ở mãi ở đó dù bạn dã áp dụng nhiều cách.
    <br> <br>
                                    Trên thực tế có rất nhiều phương pháp giảm béo, nhưng không phải phương pháp nào cũng mang lại hiệu quả như mong đợi.
                                    Nhưng cổ máy siêu giảm béo Lipo-S Burner được chứng thực là một trong những phương pháp giảm béo đem lại hiệu quả
                                    nhanh nhất, an toàn và lành tính cho người sử dụng giảm 8-15 cm, 10Kg mỡ, đồng thời cam kết điều trị bằng văn bản. 
                                    Bùng nổ siêu ưu đãi chỉ với 300k. Hãy cho chúng tôi biết tình trạng mỡ thừa của bạn và bạn đang áp dụng phương pháp 
                                    giảm béo nào để Trung tâm tư vấn phương pháp giúp bạn đạt mong muốn giảm mỡ nhanh?

                            <h2 class="mt-3"><strong>6.Bảng giá phẫu thuật thẩm mỹ tại Linh Hương </strong></h2>
                                    <img class="pt-3 pb-3" src="<?=PATH_IMG?>mimay.PNG" alt="">
                                    <div class="ml-3">
                                <b>Dù là một phương pháp thẩm mỹ đơn giản, nhưng nhấn mí lại sở hữu khá nhiều ưu điểm:</b>
                                    <p> Không mất quá nhiều thời gian, khoảng 30 phút. <br>
                                        Thủ thuật đơn giản, không đau <br>
                                        Thời gian phục hồi nhanh chóng <br>
                                        Chi phí thấp.</p> </div>
                                    <div class="ml-3">
                                    <b>Tuy nhiên, bên cạnh đó phương pháp nhấn mí cũng tồn tại một số nhược điểm:</b> <br>
                                        Nhấn mí chỉ hiệu quả với những người trẻ dưới 30 tuổi, mí mắt không có quá nhiều da thừa và mỡ. <br>
                                        Thông thường sau 2-3 năm các nếp mí sẽ mờ đi. Điều này đồng nghĩa với việc các chị em sẽ phải đi nhấn mí lần nữa.
                                    </div>
                                    <img class="pt-3 pb-3" src="<?=PATH_IMG?>muimoi.PNG" alt="">
                                <b> Thẩm mỹ môi trái tim như thế nào?</b>
                                    Bất kì chị em phụ nữ nào cũng mong ước sở hữu một gương mặt khả ái, quyến rũ mọi ánh nhìn. Trong đó, bờ môi góp phần tạo nên sức hút cho người đối diện với nụ cười ghi đậm dấu ấn. Thẩm mỹ môi trái tim chính là con đường ngắn nhất để đưa phái đẹp tới sự quyến rũ làm điên đảo nhịp tim của phái mạnh. 
                                    <br>
                                    Thẩm mỹ môi trái tim không đơn giản là việc cắt rạch vùng da môi. Trên thực tế, môi của con người có cấu tạo rất đặc biệt và nhạy cảm. Môi có 2 phần là mô khô và môi ướt, người làm thẩm mỹ môi trái tim phải làm sao chạm đến đường niêm mạc chính giữa 2 vùng da môi mới có thể tạo ra hiệu quả thẩm mỹ cho đôi môi. 
                            <h2 class="mt-3"><strong>7.Bảng giá dịch vụ gội đầu dưỡng sinh- massagefoot </strong></h2>
                                    <img class="pt-3 pb-3" src="<?=PATH_IMG?>goidau.PNG" alt="">
                                    <img src="<?=PATH_IMG?>massa.PNG" alt="">
                                <div class="ml-3">
                                    - Linh Hương chuyên cung cấp các dịch vụ gội đầu thảo dược, massage body, ấn huyệt, đắp mặt nạ, ngâm chân thảo dược... <br>
                                    - Đến Linh Hương, quý khách được chăm sóc toàn diện giúp cải thiện sức khỏe, tái tạo làn da, phục hồi vẻ đẹp của mái tóc... <br>
                                    - Spa sử dụng nguồn thảo dược thiên nhiên nhằm đảm bảo sức khỏe và đem đến hiệu quả làm đẹp cao nhất cho khách hàng.  <br>
                                    - Đội ngũ nhân viên chuyên nghiệp, tận tâm phục vụ. <br>
                                    - Không gian thoáng đãng, yên tĩnh, thích hợp để nghỉ ngơi và thư giãn sau những ngày làm việc căng thẳng. 
                                    </div>
                                    <img class="pt-3 pb-3" src="<?=PATH_IMG?>anhgoidau.jpg" alt="">
                            <h2 class="mt-3"><strong>8.Bảng giá dịch vụ mi –filter botox </strong></h2>
                            <div class="d-flex mt-3 mb-3">
                                    <img src="<?=PATH_IMG?>fiiter.PNG" alt="">
                                    <img width="45%" src="<?=PATH_IMG?>tiemmui.jpg" alt="">
                                </div>
                                <p>
                                ♦ Tiêm tạo hình thẩm mỹ cho các bạn đẹp hoàn hảo theo ý muốn chỉ sau 20 phút tiêm - nắn - chỉnh. Bạn sẽ thấy ngay sự khác biệt rõ rệt: môi trên căng đầy đều đặn hài hòa với môi dưới. 
                                Nền da môi cũng căng ẩm, mượt mà, cải thiện nét quyến rũ gấp bội phần. <br>
                                ♦ Không sưng, không bầm, không tác dụng phụ. <br>
                                ♦ Sinh hoạt bình thường ngay sau khi vừa tiêm xong (Không cần kiêng cử) <br>
                                ♦ Cam kết sử dụng filler chính hãng từ nhà sản xuất danh tiếng thế giới. </p>
                                <img class="pb-3"  src="<?=PATH_IMG?>filler.jpg" alt="">
                            <div class="container text-lg-center mt-5">

                            <h6>Để biết được các thông tin chính xác nhất về thẩm mỹ viện Linh Hương, bạn có thể tìm hiểu qua các trang thông tin:</h6>

                               <a href="https://www.facebook.com/HuongRuby.MasterPhunMayNhanTuongHoc" class="text-primary"> 
                               ► Fanpage: https://www.facebook.com/HuongRuby.MasterPhunMayNhanTuongHoc </a><br> <br>
                                <img src="<?=PATH_IMG?>logo.jpg" alt="">
                                                                                        
                                Hotline :<b> 090 203 58 96 </b> hoặc đến chi nhánh Linh Hương gần nhất để được tư vấn và sử dụng dịch vụ! <br> 
                                                            
                                <b>► TP.HẢI PHÒNG:</b> 147 Tổ 1- TT An Dương- Hải Phòng <br>
                                                            
                            <b> ► BÌNH DƯƠNG:</b> 37 Nguyễn Văn Tiết - Lái Thiêu- Thuận An- Bình Dương <br>
                                
                            <b> ► TP.HCM:</b> 660 Đường Hưng Phú, Phường 10, Quận 8, Thành phố Hồ Chí Minh, Việt Nam
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>
